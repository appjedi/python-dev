const { Sequelize, DataTypes } = require('sequelize');
//const { iniParams } = require('request-promise');
let sequelize;
let connection;
const connLocal = {
    database:"dev",
    user:"root",
    password:"Jedi2023",
    host: "127.0.0.1",
    port: 3306,
    dialect:"mysql"
}
const conn = {
    database:"appjedin_training",
    user:"appjedin_dba",
    password:"$Data2022",
    host: "appdojo.net",
    port: 3306,
    dialect:"mysql"
}
//module.exports =
    class MySQLDAO {
        constructor(connObj) {
            connection = connObj===undefined?conn:connObj;
            this.init();
        }
        init = () => {
            console.log("connecting to db...", connection);
            try {
                sequelize = new Sequelize(
                    connection.database,
                    connection.user,
                    connection.password,
                    {
                        host: connection.host,
                        port: connection.port,
                        dialect: connection.dialect
                    }
                );
                sequelize.authenticate().then(() => {
                    console.log("database connected");
                }).catch((error) => {
                    console.error("Unable to connect: ", error);
                })
            } catch (e) {
                console.log("connect error:");
                console.log(e);
            }
        }
        query = async (qry, values) => {
            try{
                console.log("query:", qry);
                const results = await sequelize.query(qry, {
                    replacements: values, type: sequelize.QueryTypes.SELECT
                });
                //  console.log(results);
                return results;
            }catch (ex){
                console.log("query error:", ex);
                return { status: -1, message: "error", ex: ex };
            }
        }
        execute = async (query, values) => {
            const results = await sequelize.query(query, {
                replacements: values
            });
            return results;
        }
        call = async (query, values) => {
            const results = await sequelize.query("call " + query, {
                replacements: values
            });
            return results;
        }
        getUsers = async () => {
            const results = await this.query("SELECT * FROM users", null);
            return results;
        }
        getEmailById = async (id) => {
            const result = await this.query("SELECT * FROM view_web_email_queue WHERE email_id=?", [id]);
            return result;
        }
        getTextById = async (id) => {
            const result = await this.query("SELECT * FROM view_web_text_queue WHERE text_id=?", [id]);
            return result;
        }
    }
module.exports =MySQLDAO
const main=async()=> {
    const db = new MySQLDAO(conn);
    const rows = await db.getUsers();
   // const rows = async db.getUsers();
    console.log(rows);
}
//main();