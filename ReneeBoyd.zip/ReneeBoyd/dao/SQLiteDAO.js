const { Sequelize, DataTypes, QueryTypes } = require("sequelize");

const storageProd="./data/data.db";
const storageTest="../data/data.db";
const storage=storageProd;
const GC_SQLiteCONN = {
  user: "",
  password: "",
  host: "0.0.0.0",
  dialect: "sqlite",
  pool: {
    max: 5,
    min: 0,
    idle: 10000,
  },
  storage: storage,
};

let sequelize;
let connection;
//
class SQLiteDAO {
    constructor(connObj) {
        if (connObj==undefined||connObj===null)
        {
            connObj = GC_SQLiteCONN;
        }
        console.log ("SQLiteDAO", connObj);
        connection = connObj;
        this.init();
    }
    init = async () => {
        sequelize = new Sequelize(connection);
        sequelize
        .authenticate()
        .then(() => {
            console.log("database connected");
        })
        .catch((error) => {
            console.error("Unable to connect: ", error);
        });
    };
    query = async (query, values) => {
        try {
          const results = await sequelize.query(query, {
            replacements: values,
            type: QueryTypes.SELECT,
          });
          // console.log(results);
          return results;
        } catch (e) {
          console.log("query.error", e);
          return [{ status: -1, message: e }];
        }
    };
    execute = async (query, values) => {
        try {
        const results = await sequelize.query(query, {
            replacements: values,
        });
        return results;
        } catch (e) {
        console.log("execute.error", e);
        return [{ status: -1, message: e }];
        }
    };
    getUsers = async () => {
        const users = await this.query(`SELECT * FROM users`);
        return users;
    }
    createUser=async(un, pw) =>{
        try {
            const insert = `INSERT INTO users (username,password,role_id, status) VALUES(?,?,1,1);`;
            const values = [un, pw];
            this.execute(insert, values);
            console.log("user created.");
            return { status: 1, message: "user created" };
        } catch (ex) {
            console.log("error:", ex);
            return { status: -1, message: "error", ex: ex };
        }
    }
}
module.exports =SQLiteDAO
// 414-401-5454
async function insertUser(un, pw) {
  try {
    const db = new SQLConn(conn);

    const insert = `INSERT INTO users (username,password,role_id, status) VALUES(?,?, 1,1);`;
    const values = [un, pw];
    db.execute(insert, values);
    console.log("user created.");
  } catch (ex) {
    console.log("error:", ex);
  }
}

const tables = [
  "CREATE TABLE logger (id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, message VARCHAR(4000) DEFAULT NULL, log_date DATETIME DEFAULT NULL)",
  "CREATE TABLE users  (id INTEGER PRIMARY KEY AUTOINCREMENT, username VARCHAR(50),password  VARCHAR(50),role_id INTEGER, status INTEGER)",
  "CREATE TABLE contact_us (id INTEGER PRIMARY KEY, email VARCHAR(255), full_name VARCHAR(255),message VARCHAR(4000), received DATETIME, status INT)"
];
const createTables = async () => {
  try {
    const db = new SQLConn(conn);
    for (let t of tables) {
      // console.log(`about to create ${t}.`);

      db.execute(t);
      console.log(`table ${t} created.`);
    }
    //const values = [un, pw];
    console.log("table created.");
  } catch (ex) {
    console.log("error:", ex);
  }
}
const createTableUser = async () => {
  try {
    const db = new SQLiteDAO(GC_TestSQLiteCONN);

    const create =
      "CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, username VARCHAR(50),password  VARCHAR(50),role_id INTEGER, status INTEGER)";
    //const values = [un, pw];
    db.execute(create);
    console.log("table created.");
  } catch (ex) {
    console.log("error:", ex);
  }
}

async function main() {
  const db = new SQLiteDAO(GC_TestSQLiteCONN);
  const rows = await db.getUsers();
  console.log(rows);
}
//insertUser("testerb", 'Test1234');
//createTableUser();
//createTables();
//main();
