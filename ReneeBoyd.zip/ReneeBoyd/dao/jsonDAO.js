const fs = require('fs');
//module.exports =
class JSONDAO {
    constructor(docName) {
        this.docName=(docName+"").indexOf(".json")<1?`./data/${docName}.json`:docName;
        this.loadDoc();
    }
    loadDoc=()=>{
        try {
            this.list= JSON.parse(fs.readFileSync(this.docName));
            if(!this.list)
            {
                this.list=[];
            }
            console.log("load doc:",this.list);
        } catch (ex) {
            console.log("error:", ex);
        }
    }
    saveDoc=(doc)=>{
        try{
            fs.writeFileSync(this.docName, JSON.stringify(this.list, null, 2));
        } catch (ex) {
            console.log("error:", ex);
        }
    }
    find = ()=>{
        return this.list;
    }
    findById = (id) => {
        return this.list.find(x => x.id == id);
    }
    create=(doc)=>{
        try {
            const dt = new Date();
            doc['id'] = dt.getTime();
            doc['createDt']=dt;
            console.log("create doc:",doc);
            this.list.push(doc);
            console.log("list:", this.list);
            this.saveDoc(this.list);
        } catch (ex) {
            console.log("error:", ex);
        }
    }
    update=(doc)=>{
        const dt = new Date();
        doc["updateDt"] = dt;
        for (let i in list)
        {
            if(doc.id===list[i].id)
            {
                list[i]=doc;
                this.saveDoc();
                return {status:200, message:"contact updated"};
            }
        }
        return {status:-1, message:"contact not found"};
    }
}
module.exports =JSONDAO
const test = () => {
    const db = new JSONDAO("users");
    const users = db.find();
    console.log(users);
}
//test();