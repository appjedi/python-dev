const KoaRouter = require('koa-router');
class APIRouter {
    constructor(service) {
        this.service = service;
        this.router = new KoaRouter({prefix: '/api'});
        this.createRoutes();
    }
    createRoutes =()=>
    {
        this.router.get("/users", async (ctx) => {
            const users = await this.service.getUsers();
            ctx.body = users;
        });
        this.router.get("/my/users", async (ctx) => {
            const users = await this.service.getMyUsers();
            ctx.body = users;
        });
        this.router.get("/mongo/users", async (ctx) => {
            const users = await this.service.getMongoUsers(0);
            ctx.body = users;
        });
        this.router.get("/api/users/create/:un/:pw", async (ctx) =>{
            const un=ctx.params.un;
            const pw=ctx.params.pw;
            console.log ("create user:", un ,pw);
        
            const resp=await this.service.createUser(un,pw);
            ctx.body = resp;
        });
        this.router.get("/test", async (ctx) => {
            const list = await this.service.getMetaData();
            ctx.body = list;
        });
        this.router.get("/emailList", async (ctx) => {
            const list = await this.service.getEmailList();
            ctx.body = list;
        });
    }
    getRouter=()=>{
        return this.router;
    }
}

module.exports= APIRouter;