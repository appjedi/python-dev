const KoaRouter = require('koa-router');

class WebRouter {
    constructor(service) {
        this.service = service;
        this.router = new KoaRouter();
        this.createRoutes();
    }
    createRoutes =()=>
    {
        this.router.get("/", async (ctx) => {
            await ctx.render("index",{message:"Alert!    Learning Center will be closed on 5/29/24    Alert!", color: "red"});
        });
        this.router.get("/hours", async (ctx) => {
            await ctx.render("hours",{message:"Good Afternoon"});
        });
        this.router.get("/overview", async (ctx) => {
            await ctx.render("overview",{message:"Good Afternoon"});
        });
        this.router.get("/staff", async (ctx) => {
            await ctx.render("staff",{message:"Good Afternoon"});
        });
        this.router.get("/upload", async (ctx) => {
            await ctx.render("upload",{message:"Good Afternoon"});
        });
        this.router.get("/application", async (ctx) => {
            await ctx.render("application",{message:"Good Afternoon"});
        });
        this.router.get("/contactus", async (ctx) => {
            await ctx.render("contactus",{message:"Good Afternoon"});
        });
        this.router.post("/contactus", async (ctx) => {
            const contact = ctx.request.body;
            //const dao = new JSONDAO("./data/contactus.json");
            this.service.saveContact(contact);
            console.log("post.contactus:", contact);
            //  await ctx.render("index",{message:"Alert!    Learning Center will be closed on 5/29/24    Alert!", color: "red"});
            ctx.body = { status: 200, message: "contact message sent",contact:contact };
        });
        
        this.router.get("/users/create/:un/:pw", async (ctx) =>{
            const un=ctx.params.un;
            const pw=ctx.params.pw;
            console.log ("create user:", un ,pw);
        
            const resp=await this.service.createUser(un,pw);
            ctx.body = resp;
        });
        this.router.get("/message/:id", async (ctx) => {
            const id=parseInt(ctx.params.id);
            if(id>0)
            {
                const messages = this.service.getContacts(id);
                ctx.body=messages;
            }else {
                const messages = this.service.getContacts(0);
                ctx.body=messages;
            }
        });
    }
    getRouter=()=>{
        return this.router;
    }
}

module.exports= WebRouter;