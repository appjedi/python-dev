require("dotenv").config()
const cors = require("@koa/cors");
const fs = require('fs');

const Koa = require('koa');
//const KoaRouter = require('koa-router');
const json = require('koa-json');
const render = require('koa-ejs');
const bodyParser = require('koa-bodyparser');
const path = require('path');
const session = require('koa-session');
const { release } = require("os");
var serve = require('koa-static');
const MainService = require('./services/service.js');
const APIRouter =require('./routes/api.js');
const WebRouter =require('./routes/web.js');
const service = new MainService();

const app = new Koa();
app.use(cors());

const PORT = 3000;
//app.use(session());
app.keys = ['Shh, its a secret!'];
app.use(session(app));
app.use(json());
app.use(bodyParser());
//app.use(router.static('public'));
app.use(serve('./public'));

const GC_RELEASE = "2024-09-24";

let ssn;
let fileName;

render(app, {
  root: path.join(__dirname, 'views'),
  layout: 'layout',
  viewExt: 'html',
  cache: false,
  debug: false
});

const webRouter = new WebRouter(service).getRouter();
const apiRouter = new APIRouter(service).getRouter();
app.use(webRouter.routes()).use(webRouter.allowedMethods());
app.use(apiRouter.routes()).use(apiRouter.allowedMethods());

app.listen(PORT, () => {
  console.log("listening on port:", PORT);
})