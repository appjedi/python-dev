
const temp = "Product ID,Product Owner,Product Owner ID,Product Name,Product Code,Vendor Name,Vendor ID,Product Active,Manufacturer,Product Category,Sales Start Date,Sales End Date,Support Start Date,Support End Date,Created By,Created by ID,Modified By,Modified by ID,Created Time,ModifiedTime,UnitPrice,CommissionRate,Tax,UsageUnit,QtyOrdered,QuantityinStock,ReorderLevel,Handler,HandlerId,QuantityinDemand,Description,Taxable,Tag,RecordId,PBPartNo,PBItemType,PBSubtype,PBBin,PBSubcategory,PBMinQty,PBStandardCost,PBItemStatus,PBFeatures,PBAssyType,PBInactive"

