import dotenv from 'dotenv'
import Koa from 'koa';
import { Context, DefaultState } from 'koa';
//import KoaRouter from 'koa-router';
import * as Router from "koa-router";

import json from 'koa-json';
import render from 'koa-ejs';
import bodyParser from 'koa-bodyparser';
import path from 'path';
import session from 'koa-session';


dotenv.config();

const app = new Koa();
const router = new Router();
const PORT = 3000;
//app.use(session());
app.keys = ["Shh, its a secret!"];
app.use(session(null, app));
app.use(json(null));
app.use(bodyParser());
const GC_RELEASE = "2023-10-02";

let ssn;

const GC_SERVER_URL = process.env.SERVER_URL;
render(app, {
  root: path.join(__dirname, "views"),
  layout: "layout",
  viewExt: "html",
  cache: false,
  debug: false,
});

router.get("/", async (ctx: Context, next) => {
  //await ctx.render("stripe", { serverURL: GC_SERVER_URL });
  ctx.body="Hello";
});

app.listen(PORT, () => {
  console.log("TS-listening on port:", PORT);
});

export { app };