const nodeMailer = require("nodemailer");
const SQLiteDAO= require('./dao/SQLiteDAO.js');
const JSONDAO = require('./dao/jsonDAO.js');
const MySQLDAO = require('./dao/MySQLDAO.js');
const MongoDAO = require('./dao/MongoDAO.js');
const gmailProps = {
    from: "App Jedi <appjedi.net@gmail.com>",
    host: "smtp.gmail.com",
    port: 465,
    secure: true,
    auth: {
        user: "appjedi.net@gmail.com",
        pass: "dekxwtulmsryovls",
    },
};

class MainService {
    dao;
        constructor(connObj) {
            console.log("connObj", connObj);
            this.dao = new SQLiteDAO();
            this.contactDAO = new JSONDAO("contactus");
            this.mySQLDAO = new MySQLDAO(connObj);
            this.mongoDAO = new MongoDAO();
            this.mailAuth = gmailProps
        }
        getUsers = async () => {
            const users = await this.dao.getUsers();
            return users;
        }
        getMyUsers = async () => {
            const users = await this.mySQLDAO.getUsers();
            return users;
        }
        
        getMongoUsers = async (id) => {
            const users = await this.mongoDAO.getUsers(id);
            return users;
        }
            
        createUser=async (un, pw) => {
            const resp = await this.dao.createUser(un, pw);
            return resp;
        }
        getContacts =  (id) => {
            if(id===0){
                const messages = this.contactDAO.find();
                return messages;
            }else {
                const messages =  this.contactDAO.findById(id);
                return messages;
            }
        }
        saveContact = async (contact) => {
            if(contact.id===0)
            {
                this.contactDAO.create(contact);
                const msg = `
                    <p>Name: ${contact.fullName}</p>
                    <p>Email: ${contact.email}</p>
                    <p>Message: ${contact.message}</p>
                    <p>Join Mail List: ${contact.joinMailList?"Yes":"No"}</p>`;

                const contactEmail = {
                    to: "appjedi.net@gmail.com",
                    from: "appjedi.net@gmail.com",
                    subject: "Contact Message.",
                    html: msg
                }
                const resp = await this.sendMail(contactEmail);
                console.log("sendMail: " + resp);
            }else{
                this.contactDAO.update(contact);
            }
        }
        getEmailList=async()=>{
            const list = await this.contactDAO.find();
            const emailList=[];
            for (let c of list)
            {
                if(c['joinMailList'])
                {
                    emailList.push(c);
                }
            }
            return emailList;
        }
        getMetaData = async () => {
            const dao = new JSONDAO("./data/metadata.json");
            const schedule = await dao.find();
            return schedule;
        }
        sendMail = async (options) => {
            try {
                const transporter = nodeMailer.createTransport({
                    host: this.mailAuth.host,
                    port: this.mailAuth.port,
                    auth: {
                        user: this.mailAuth.auth.user,
                        pass: this.mailAuth.auth.pass
                    }
                });
                options.from = this.mailAuth.from;
                console.log("sendMail:", options, this.mailAuth)

                const info = await transporter.sendMail(options);
                const resp =
                {
                    status: 1, message: "Email sent successfully.", info: info
                }
                //messageId: info.messageId, accepted: info.accepted, rejected: info.rejected

                console.log("sendMail.response:", resp);
                return resp;
            } catch (ex) {
                console.log("sendMail.error:", ex);
                return { status: -1, message: "Error" }
            }
        }
}
module.exports =MainService;
const sampleEmailMessage = {
    to: "place@holder.com",
    from: "appjedi.net@gmail.com",
    subject: "Survey Request Test.",
    html: "<h1>Hello World!</h1>",
    attachments: [
    {
        filename: "officeHours.pdf",
        path: "./officeHours.pdf"
    }
  ]
}
