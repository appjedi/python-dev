const fs = require("fs");
const { parse } = require("csv-parse");
const readline = require('readline');
const data = []

const parseFile = async (fn) => {
    const fileStream = fs.createReadStream(fn);

    const rl = readline.createInterface({
        input: fileStream,
        crlfDelay: Infinity
    });
    let currentPBItemID = "";
    let standardCost = 0;
    let mfgList = 0;
    let ProductName = "";
    let vendVendorNameor = "";
    for await (const line of rl) {
        // Each line in input.txt will be successively available here as `line`.
        const row = line.split(",");

        let temp = (row[0] + "").trim();
        if (temp === "PB Item ID")
        {
            temp = "";    
        }
        if (temp.length>4) {
            currentPBItemID = temp;
            ProductName = row[1];
            standardCost = parseFloat(row[7]);
            mfgList = parseFloat(row[8]);
            VendorName = row[9];
        }
        incomeGLCode = (row[2] + "").trim();
        costGLCode = (row[3] + "").trim();
        console.log("PARSING:", currentPBItemID, incomeGLCode, costGLCode);
        if (incomeGLCode.length > 5 && costGLCode.length >5 && currentPBItemID.length >4) {
            const item = { PBItemID: currentPBItemID, incomeGLCode: incomeGLCode, costGLCode: costGLCode, ProductName: ProductName, VendorName: VendorName, PBStandardCost: standardCost, PBMfgList: mfgList }
            console.log("PUSH:",item);
            data.push(item);
            currentPBItemID = ""
        }
    }
}

function createOutputCSV(data, fileName) {
    let content = "";
    for (row of data) {
        let sc = row.PBStandardCost;
        if (isNaN(sc) || (sc + "") == "NaN") {
            sc = 0;
        }
        const line = `${row.PBItemID},${row.incomeGLCode},${row.costGLCode},${sc},${row.PBMfgList}\n`;
        content += line;
        //console.log(line);
    }
    fs.writeFileSync(fileName, content);
}
const productColumns = "Product ID,Product Owner,Product Owner ID,Product Name,Product Code,Vendor Name,Vendor ID,Product Active,Manufacturer,Product Category,Sales Start Date,Sales End Date,Support Start Date,Support End Date,Created By,Created by ID,Modified By,Modified by ID,Created Time,Modified Time,Unit Price,Commission Rate,Tax,Usage Unit,Qty Ordered,Quantity in Stock,Reorder Level,Handler,Handler Id,Quantity in Demand,Description,Taxable,Tag,Record Id,PB Part No.,PB Item Type,PB Subtype,PB Bin,PB Subcategory,PB Min Qty.,PB Standard Cost,PB Item Status,PB Features,PB Assy. Type,PB Inactive,incomeGLCode,costGLCode"
function createProductCSV(data, fileName) {
    let content = productColumns + "\n";
    for (row of data) {
        // console.log("DATA", data);
        let line = "";
        for (let i in columns) {
            line += row[columns[i]] + ",";
        }
        line += row['incomeGLCode'] + "," + row['costGLCode'] + "\n";
        content += line;
        //console.log(line);
    }
    fs.writeFileSync(fileName, content);
}
const products = [];

const findGLCode = (id) => {
    for (let row of data) {
        
        if (row.PBItemID === id) {
            return row;
        }
    }
    return null;
}

const columns = ("ProductID,ProductOwner,ProductOwnerID,ProductName,ProductCode,VendorName,VendorID,ProductActive,Manufacturer,ProductCategory,SalesStartDate,SalesEndDate,SupportStartDate,SupportEndDate,CreatedBy,CreatedByID,ModifiedBy,ModifiedByID,CreatedTime,ModifiedTime,UnitPrice,CommissionRate,Tax,UsageUnit,QtyOrdered,QuantityinStock,ReorderLevel,Handler,HandlerId,QuantityinDemand,Description,Taxable,Tag,RecordId,PBPartNo,PBItemType,PBSubtype,PBBin,PBSubcategory,PBMinQty,PBStandardCost,PBItemStatus,PBFeatures,PBAssyType,PBInactive").split(",");

const createProduct = (arr) => {
    const product = {}
    for (let i in arr) {
        product[columns[i]] = arr[i]
    }
    product["incomeGLCode"] = "";
    product["costGLCode"] = "";

    return product;
}
const loadProducts = async (fn) => {
    const fileStream = fs.createReadStream(fn);
    // id = 4
    const rl = readline.createInterface({
        input: fileStream,
        crlfDelay: Infinity
    });
    let foundCount = 0;

    for await (const line of rl) {
        // Each line in input.txt will be successively available here as `line`.
        const row = line.split(",");
        const product = createProduct(row);
        //console.log("PRODUCT", product);
        const d = findGLCode(product.ProductCode); // 4=ProductCode
console.log ("FINDING: ", product.ProductCode)
        if (d) {
            console.log("FOUND:", d);
            ++foundCount;
            product.ProductName = d.ProductName;
            product.costGLCode = d.costGLCode;
            product.incomeGLCode = d.incomeGLCode;
            product.VendorName = d.VendorName;
            //  console.log("FOUND", d)
        }
        products.push(product);
        //console.log("PRODUCT", product);
    }
    // console.log("PRODUCTS", products);
}
const main = async () => {
    await parseFile("./source.csv");
    // console.log("DATA", data);
    createOutputCSV(data, "output.csv");
    //console.log("done");
    await loadProducts("zoho_crm_products.csv");
    console.log("PRODUCTS", products.length);
    createProductCSV(products, "products.csv");
}
main();


